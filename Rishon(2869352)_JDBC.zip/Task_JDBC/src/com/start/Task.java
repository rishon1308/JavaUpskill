package com.start;
import java.util.*;
import java.sql.*;

public class Task {
    String s = "";
    int n = 0;
    String d = "";
    int sal = 0;
    double sal1 = 0.0;

    static final String URL = "jdbc:mysql://localhost:3306/jdbc_demo";
    static final String USER = "root";
    static final String PASS = "Root123$";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void create() {
        Scanner sc = new Scanner(System.in);
        boolean f1 = true;
        String s1;
        while (f1) {
            System.out.println("Enter the name (max of 3 names allowed)");
            s1 = sc.nextLine();
            int whitespace = 0;
            for (int i = 0; i < s1.length(); i++) {
                if (s1.charAt(i) == ' ') {
                    whitespace++;
                }
            }
            if (whitespace > 2) {
                f1 = false;
                System.out.println("Invalid Name");
            } else {
                s = s1;
                break;
            }
        }

        boolean f = true;
        int age = 0;
        while (f && f1) {
            System.out.println("Enter the correct age (20 to 60)");
            age = sc.nextInt();
            if (age < 20 || age > 60) {
                f = false;
                System.out.println("Invalid Age");
            } else {
                n = age;
                break;
            }
        }
        sc.nextLine();

        boolean f2 = true;
        while (f1 && f && f2) {
            System.out.println("Enter Designation - P(Program), M(Manager), T(Tester)");
            d = sc.nextLine();
            if (d.equals("P") || d.equals("M") || d.equals("T")) {
                if (d.equals("P")) {
                    d = "Programer";
                    sal = 20000;
                }
                if (d.equals("M")) {
                    d = "Manager";
                    sal = 25000;
                }
                if (d.equals("T")) {
                    d = "Tester";
                    sal = 15000;
                }
                f2 = false;
            }
        }

        if (f1 && f && !f2) {
            try (Connection con = DriverManager.getConnection(URL, USER, PASS);
                 PreparedStatement ps = con.prepareStatement(
                         "INSERT INTO employee(name, age, designation, salary) VALUES (?, ?, ?, ?)")) {
                ps.setString(1, s);
                ps.setInt(2, n);
                ps.setString(3, d);
                ps.setDouble(4, sal);
                ps.executeUpdate();
            } catch (SQLException e) {
                System.out.println("DB Error in Create: " + e.getMessage());
            }
        }
    }

    public void display() {
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement ps = con.prepareStatement(
                     "SELECT name, age, designation, salary FROM employee");
             ResultSet rs = ps.executeQuery()) {

            System.out.println("---- File Content using JDBC ----");
            while (rs.next()) {
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String des = rs.getString("designation");
                double salary = rs.getDouble("salary");
                System.out.println("Name: " + name + ", Age: " + age + ", Designation: " + des + ", Salary: " + salary);
            }

        } catch (SQLException e) {
            System.out.println("DB Error in Display: " + e.getMessage());
        }

        System.out.println("\nYour name is: " + s);
        System.out.println("Your age is: " + n);
        System.out.println("Your salary is " + sal1);
        System.out.println("Your designation is " + d);
    }

    public void update() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the name of the employee");
        String s = sc.nextLine();
        boolean f = true;
        double su = 0;
        while (f) {
            System.out.println("Enter the correct salary upgrade percentage (1 to 10)");
            su = sc.nextDouble();
            if (su < 0.0 || su > 10.0) {
                f = false;
                System.out.println("Invalid Range");
            } else {
                break;
            }
        }
        if (f) {
            double currentSalary = 0.0;
            try (Connection con = DriverManager.getConnection(URL, USER, PASS);
                 PreparedStatement ps = con.prepareStatement(
                         "SELECT salary FROM employee WHERE name = ?")) {
                ps.setString(1, s);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        currentSalary = rs.getDouble(1);
                    } else {
                        System.out.println("Employee not found");
                        return;
                    }
                }
            } catch (SQLException e) {
                System.out.println("DB Error in Update (select): " + e.getMessage());
                return;
            }

            sal1 = currentSalary + currentSalary * su / 100.0;
            System.out.println("Raised salary is " + sal1);

            try (Connection con = DriverManager.getConnection(URL, USER, PASS);
                 PreparedStatement ps = con.prepareStatement(
                         "UPDATE employee SET salary = ? WHERE name = ?")) {
                ps.setDouble(1, sal1);
                ps.setString(2, s);
                ps.executeUpdate();
            } catch (SQLException e) {
                System.out.println("DB Error in Update (update): " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        Task t = new Task();
        Scanner sc = new Scanner(System.in);
        int n = 0;
        while (n != 4) {
            System.out.println("1. Create");
            System.out.println("2. Display");
            System.out.println("3. Raise Salary");
            System.out.println("4. Exit");
            n = sc.nextInt();
            sc.nextLine();

            if (n == 1) {
                char ch = 'Y';
                while (ch == 'Y') {
                    t.create();
                    System.out.println("Enter Y to add more, else N");
                    ch = sc.nextLine().charAt(0);
                }
            }
            if (n == 2) {
                t.display();
            }
            if (n == 3) {
                t.update();
            }
            if (n == 4) {
                System.out.println("Thanks for using!!");
                break;
            }
        }
    }
}